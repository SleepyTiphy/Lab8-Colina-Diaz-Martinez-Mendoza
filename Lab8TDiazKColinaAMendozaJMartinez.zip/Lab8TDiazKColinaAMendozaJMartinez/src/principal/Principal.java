package principal;

import java.util.ArrayList;
import logica.Estudiantes;
import grafico.Formulario;

public class Principal {

    public static void main(String[] args) {
        ArrayList<Estudiantes> estudiantes = new ArrayList<Estudiantes>();
        Formulario formulario = new Formulario(estudiantes);
        formulario.setVisible(true);
    }
}
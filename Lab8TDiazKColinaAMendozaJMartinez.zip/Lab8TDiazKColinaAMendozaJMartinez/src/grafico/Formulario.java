package grafico;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import logica.Estudiantes;
import logica.Becas;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class Formulario extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textNombre;
    private JTextField textIndice;
    private JTextField textCedula;
    private Estudiantes estudiante;
    private JComboBox<String> comboBoxCarreras;
    private JComboBox<String> comboBoxSexo; // Nuevo JComboBox para el sexo
    private ArrayList<Estudiantes> estudiantes;

    public Formulario(ArrayList<Estudiantes> estudiantes) {
        this.estudiantes = estudiantes;
        initialize();
    }

    private void initialize() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 932, 552);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Información de estudiantes");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
        lblNewLabel.setBounds(277, 10, 271, 62);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Nombre:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_1.setBounds(21, 97, 95, 22);
        contentPane.add(lblNewLabel_1);

        textNombre = new JTextField();
        textNombre.setBounds(130, 100, 130, 26);
        contentPane.add(textNombre);
        textNombre.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Cédula:");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_2.setBounds(21, 141, 95, 22);
        contentPane.add(lblNewLabel_2);

        textCedula = new JTextField();
        textCedula.setBounds(130, 144, 130, 26);
        contentPane.add(textCedula);
        textCedula.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("Carrera:");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_3.setBounds(21, 185, 95, 22);
        contentPane.add(lblNewLabel_3);

        comboBoxCarreras = new JComboBox<>();
        comboBoxCarreras.setModel(new DefaultComboBoxModel<>(new String[] {"Ingeniería", "Medicina", "Derecho", "Arquitectura"}));
        comboBoxCarreras.setBounds(130, 188, 130, 26);
        contentPane.add(comboBoxCarreras);

        JLabel lblNewLabel_4 = new JLabel("Índice:");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_4.setBounds(21, 229, 95, 22);
        contentPane.add(lblNewLabel_4);

        textIndice = new JTextField();
        textIndice.setBounds(130, 232, 130, 26);
        contentPane.add(textIndice);
        textIndice.setColumns(10);

        JLabel lblNewLabel_5 = new JLabel("Sexo:");
        lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNewLabel_5.setBounds(21, 273, 95, 22);
        contentPane.add(lblNewLabel_5);

        comboBoxSexo = new JComboBox<>();
        comboBoxSexo.setModel(new DefaultComboBoxModel<>(new String[] {"Masculino", "Femenino"}));
        comboBoxSexo.setBounds(130, 276, 130, 26);
        contentPane.add(comboBoxSexo);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                guardarDatos();
            }
        });
        btnGuardar.setBounds(130, 324, 117, 29);
        contentPane.add(btnGuardar);

        JButton btnReportes = new JButton("Reportes");
        btnReportes.setBounds(130, 365, 117, 29);
        contentPane.add(btnReportes);

        btnReportes.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                dispose();
                
                Becas becas = new Becas();

                
                for (Estudiantes estudiante : estudiantes) {
                    becas.agregarEstudiante(estudiante);
                }
                
                Reportes reportes = new Reportes(becas);
                reportes.setVisible(true);
            }
        });
    }

    private void guardarDatos() {
        try {
            String nombre = textNombre.getText();
            String cedula = textCedula.getText();
            double indice = Double.parseDouble(textIndice.getText());
            String carrera = (String) comboBoxCarreras.getSelectedItem();
            String sexo = (String) comboBoxSexo.getSelectedItem();

            if (indice < 0 || indice > 4) {
                throw new NumberFormatException("Índice fuera de rango");
            }

            Estudiantes estudiante = new Estudiantes(nombre, cedula, carrera, indice, sexo);

            System.out.println("Información del estudiante guardada: " + estudiante.toString());
            estudiantes.add(estudiante);

            JOptionPane.showMessageDialog(this, "Información guardada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            textNombre.setText("");
            textCedula.setText("");
            textIndice.setText("");
            comboBoxCarreras.setSelectedIndex(-1);
            comboBoxSexo.setSelectedIndex(-1);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese datos válidos para Índice.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Ocurrió un error al guardar los datos.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
}
    
    
    
package grafico;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import logica.Becas;
import logica.Estudiantes;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Reportes extends JFrame {
    private JTextArea textAreaBecados;
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textFieldCedula;
    private JTextField textFieldCarrera;
    private JTextField textFieldSexo;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Reportes frame = new Reportes(new Becas());
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Reportes(Becas becas) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 666, 483);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Reportes");
        lblNewLabel.setBounds(238, 10, 149, 46);
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 32));
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Estudiantes Becados:");
        lblNewLabel_1.setBounds(52, 66, 221, 35);
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        contentPane.add(lblNewLabel_1);

        textAreaBecados = new JTextArea();
        textAreaBecados.setEditable(false);
        textAreaBecados.setBounds(52, 111, 184, 220);
        contentPane.add(textAreaBecados);

        JLabel lblCedula = new JLabel("Buscar por Cédula:");
        lblCedula.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblCedula.setBounds(276, 66, 137, 35);
        contentPane.add(lblCedula);

        textFieldCedula = new JTextField();
        textFieldCedula.setBounds(423, 72, 130, 26);
        contentPane.add(textFieldCedula);
        textFieldCedula.setColumns(10);

        JButton btnBuscarCedula = new JButton("Buscar");
        btnBuscarCedula.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarPorCedula(becas);
            }
        });
        btnBuscarCedula.setBounds(563, 71, 85, 29);
        contentPane.add(btnBuscarCedula);

        JLabel lblCarrera = new JLabel("Buscar por Carrera:");
        lblCarrera.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblCarrera.setBounds(276, 113, 137, 35);
        contentPane.add(lblCarrera);

        textFieldCarrera = new JTextField();
        textFieldCarrera.setBounds(423, 119, 130, 26);
        contentPane.add(textFieldCarrera);
        textFieldCarrera.setColumns(10);

        JButton btnBuscarCarrera = new JButton("Buscar");
        btnBuscarCarrera.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarPorCarrera(becas);
            }
        });
        btnBuscarCarrera.setBounds(563, 118, 85, 29);
        contentPane.add(btnBuscarCarrera);

        JLabel lblSexo = new JLabel("Buscar por Sexo:");
        lblSexo.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblSexo.setBounds(276, 160, 137, 35);
        contentPane.add(lblSexo);

        textFieldSexo = new JTextField();
        textFieldSexo.setBounds(423, 166, 130, 26);
        contentPane.add(textFieldSexo);
        textFieldSexo.setColumns(10);

        JButton btnBuscarSexo = new JButton("Buscar");
        btnBuscarSexo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarPorSexo(becas);
            }
        });
        btnBuscarSexo.setBounds(563, 165, 85, 29);
        contentPane.add(btnBuscarSexo);

        mostrarBecados(becas);
    }

    void mostrarBecados(Becas becas) {
        System.out.println("Estudiantes becados obtenidos: " + becas.obtenerEstudiantesBecados().size());

        StringBuilder sb = new StringBuilder();
        sb.append("Nombres de los Estudiantes:\n");

        for (String nombre : becas.obtenerEstudiantesBecados()) {
            sb.append(nombre).append("\n");
        }

        textAreaBecados.setText(sb.toString());
    }

    private void buscarPorCedula(Becas becas) {
        String cedula = textFieldCedula.getText();

        Estudiantes estudiante = becas.buscarPorCedula(cedula);
        if (estudiante != null) {
            textAreaBecados.setText("Estudiante encontrado:\n" + estudiante.getNombre());
        } else {
            textAreaBecados.setText("No se encontró un estudiante con esa cédula.");
        }
    }

    private void buscarPorCarrera(Becas becas) {
        String carrera = textFieldCarrera.getText();

        ArrayList<String> becadosPorCarrera = becas.buscarBecadosPorCarrera(carrera);
        StringBuilder sb = new StringBuilder();
        sb.append("Estudiantes becados en ").append(carrera).append(":\n");

        for (String nombre : becadosPorCarrera) {
            sb.append(nombre).append("\n");
        }

        textAreaBecados.setText(sb.toString());
    }

    private void buscarPorSexo(Becas becas) {
        String sexo = textFieldSexo.getText().trim();

        if (sexo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un sexo válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ArrayList<String> becadosPorSexo = becas.buscarBecadosPorSexo(sexo);
        StringBuilder sb = new StringBuilder();
        sb.append("Estudiantes becados de sexo ").append(sexo).append(":\n");

        for (String nombre : becadosPorSexo) {
            sb.append(nombre).append("\n");
        }

        textAreaBecados.setText(sb.toString());
    }
}

package logica;

public class Estudiantes {
    private static final double INDICE_MINIMO = 0.0;
    private static final double INDICE_MAXIMO = 3.0;

    private String nombre;
    private String cedula;
    private String carrera;
    private double indiceAcademico;
    private String sexo;

    public Estudiantes(String nombre, String cedula, String carrera, double indiceAcademico, String sexo) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.carrera = carrera;
        setIndiceAcademico(indiceAcademico);
        this.sexo = sexo;
    }

    public void setIndiceAcademico(double indiceAcademico) {
        if (indiceAcademico >= INDICE_MINIMO && indiceAcademico <= INDICE_MAXIMO) {
            this.indiceAcademico = indiceAcademico;
        } else {
            throw new IllegalArgumentException("Índice académico debe estar entre " + INDICE_MINIMO + " y " + INDICE_MAXIMO + ".");
        }
    }

    public double getIndiceAcademico() {
        return indiceAcademico;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public String getCarrera() {
        return carrera;
    }

    public String getSexo() {
        return sexo;
    }
}

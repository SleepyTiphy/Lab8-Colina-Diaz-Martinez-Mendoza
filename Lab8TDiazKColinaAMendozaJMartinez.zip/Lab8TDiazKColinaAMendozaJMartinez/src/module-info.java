/**
 * 
 */
/**
 * 
 */
module Lab8Tiph {
	requires java.desktop;
}